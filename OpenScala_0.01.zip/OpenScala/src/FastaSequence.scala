
class FastaSequence {

  var header : String = ""    // Fasta Sequence header line

  var sequence : String = ""    // FASTA sequence

}  // class FastaSequence

